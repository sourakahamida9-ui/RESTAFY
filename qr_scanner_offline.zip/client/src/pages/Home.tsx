import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { QrCode, Wifi, Lock, Zap } from "lucide-react";
import { useLocation } from "wouter";
import { useServiceWorker } from "@/hooks/useServiceWorker";
import { useEffect } from "react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const { isSupported, isOnline, registerPeriodicSync } = useServiceWorker();

  // Enregistrer la synchronisation périodique quand l'utilisateur est connecté
  useEffect(() => {
    if (isAuthenticated && isSupported) {
      registerPeriodicSync(300000); // 5 minutes
    }
  }, [isAuthenticated, isSupported, registerPeriodicSync]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <QrCode className="w-8 h-8 text-indigo-600" />
            <h1 className="text-2xl font-bold text-gray-900">QR Scanner Offline</h1>
          </div>
          <div className="flex items-center gap-4">
            {/* Service Worker Status */}
            {isSupported && (
              <div className="text-xs px-3 py-1 rounded-full bg-gray-100">
                {isOnline ? '✓ Online' : '⚠ Offline'}
              </div>
            )}
            {isAuthenticated ? (
              <>
                <span className="text-sm text-gray-600">Bienvenue, {user?.name}</span>
                <Button onClick={() => navigate("/scanner")}>Acceder au scanner</Button>
              </>
            ) : (
              <Button onClick={() => (window.location.href = getLoginUrl())}>
                Se connecter
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Scanner QR Securise et Performant
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Une application elegante pour scanner les billets d'evenements en temps reel avec support complet du mode hors-ligne et synchronisation bidirectionnelle.
          </p>
          {isAuthenticated ? (
            <Button size="lg" onClick={() => navigate("/scanner")}>
              Commencer a scanner
            </Button>
          ) : (
            <Button size="lg" onClick={() => (window.location.href = getLoginUrl())}>
              Se connecter pour commencer
            </Button>
          )}
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-16">
          <Card className="p-6 hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <QrCode className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Scan Rapide</h3>
            <p className="text-gray-600 text-sm">Scannez les billets en temps reel avec feedback visuel immediat</p>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <Wifi className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Mode Offline</h3>
            <p className="text-gray-600 text-sm">Continuez a scanner sans connexion internet, synchronisation automatique {isSupported && '(Service Worker activé)'}</p>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <Lock className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Securise</h3>
            <p className="text-gray-600 text-sm">Validation atomique cote serveur pour eviter les doublons</p>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
              <Zap className="w-6 h-6 text-orange-600" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Performant</h3>
            <p className="text-gray-600 text-sm">Interface fluide et reactive avec animations elegantes</p>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 bg-white/50 mt-20">
        <div className="max-w-7xl mx-auto px-4 py-8 text-center text-gray-600">
          <p>© 2026 QR Scanner Offline. Tous droits reserves.</p>
        </div>
      </footer>
    </div>
  );
}
