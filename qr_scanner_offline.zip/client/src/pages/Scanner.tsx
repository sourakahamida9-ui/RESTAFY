import { useState, useEffect } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { QRScanner, type QRScanResult } from '@/components/QRScanner';
import { ScanDashboard } from '@/components/ScanDashboard';
import { trpc } from '@/lib/trpc';
import { useOfflineSync } from '@/hooks/useOfflineSync';
import { saveScan, getEventStatistics } from '@/lib/db';
import { LogOut, Download } from 'lucide-react';

interface EventData {
  id: number;
  title: string;
  location?: string;
  startTime: Date;
}

/**
 * Main scanner page with QR scanning and dashboard
 */
export default function Scanner() {
  const { user, logout } = useAuth();
  const [selectedEvent, setSelectedEvent] = useState<EventData | null>(null);
  const [eventStats, setEventStats] = useState({ totalTickets: 0, scannedTickets: 0, scanPercentage: 0 });

  const { isOnline, isSyncing, pendingScans, performSync } = useOfflineSync(selectedEvent?.id || 0);
  const validateQR = trpc.tickets.validateQR.useMutation();
  const eventsList = trpc.events.list.useQuery();
  const eventWithTickets = trpc.events.getWithTickets.useQuery(
    { eventId: selectedEvent?.id || 0 },
    { enabled: !!selectedEvent }
  );

  // Update event statistics when selected
  useEffect(() => {
    if (selectedEvent) {
      const updateStats = async () => {
        const stats = await getEventStatistics(selectedEvent.id);
        setEventStats(stats);
      };
      updateStats();
      const interval = setInterval(updateStats, 10000);
      return () => clearInterval(interval);
    }
  }, [selectedEvent]);

  const handleScan = async (qrCodeData: string): Promise<QRScanResult> => {
    if (!selectedEvent) {
      return {
        success: false,
        status: 'error',
        message: 'No event selected',
      };
    }

    const startTime = Date.now();

    try {
      // Validate QR code
      const result = await validateQR.mutateAsync({
        qrCodeData,
        eventId: selectedEvent.id,
        deviceType: /Mobile|Android|iPhone/.test(navigator.userAgent) ? 'mobile' : 'desktop',
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        language: navigator.language || 'unknown',
      });

      const scanTimeMs = Date.now() - startTime;

      // Save to local DB
      if (result.success) {
        await saveScan({
          ticketId: 0, // Will be resolved on sync
          ticketNumber: result.ticket?.ticketNumber || '',
          qrCodeData,
          scannedAt: Date.now(),
          scanTimeMs,
          deviceType: /Mobile|Android|iPhone/.test(navigator.userAgent) ? 'mobile' : 'desktop',
          syncStatus: 'synced',
          eventId: selectedEvent.id,
        });

        // Record behavioral data
        // await trpc.scan.recordBehavior.mutate({
        //   eventId: selectedEvent.id,
        //   eventType: 'scan_success',
        //   scanTimeMs,
        //   deviceType: /Mobile|Android|iPhone/.test(navigator.userAgent) ? 'mobile' : 'desktop',
        //   timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        //   language: navigator.language || 'unknown',
        // });

        // Update local stats
        const stats = await getEventStatistics(selectedEvent.id);
        setEventStats(stats);
      }

      return {
        success: result.success,
        status: result.status as 'success' | 'duplicate' | 'invalid' | 'error',
        message: result.message,
        ticket: result.ticket ? {
          ticketNumber: result.ticket.ticketNumber,
          customerName: result.ticket.customerName,
          customerEmail: result.ticket.customerEmail || undefined,
        } : undefined,
      };
    } catch (error) {
      const scanTimeMs = Date.now() - startTime;

      // Save failed scan to local DB for analytics
      await saveScan({
        ticketId: 0, // Will be resolved on sync
        ticketNumber: '',
        qrCodeData,
        scannedAt: Date.now(),
        scanTimeMs,
        deviceType: /Mobile|Android|iPhone/.test(navigator.userAgent) ? 'mobile' : 'desktop',
        syncStatus: 'pending',
        eventId: selectedEvent.id,
      });

      // Record failed scan for analytics
      // await trpc.scan.recordBehavior.mutate({
      //   eventId: selectedEvent.id,
      //   eventType: 'scan_failed',
      //   scanTimeMs,
      //   errorType: error instanceof Error ? error.message : 'Unknown error',
      //   deviceType: /Mobile|Android|iPhone/.test(navigator.userAgent) ? 'mobile' : 'desktop',
      //   timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      //   language: navigator.language || 'unknown',
      // });

      return {
        success: false,
        status: 'error',
        message: error instanceof Error ? error.message : 'Scan error',
        ticket: undefined,
      };
    }
  };

  const handleDownloadTickets = async () => {
    if (!selectedEvent || !eventWithTickets.data) return;

    try {
      const dataStr = JSON.stringify(eventWithTickets.data.tickets, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `tickets-${selectedEvent.id}-${new Date().toISOString()}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading tickets:', error);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="p-8 max-w-md w-full">
          <h1 className="text-2xl font-bold mb-4">QR Scanner</h1>
          <p className="text-gray-600 mb-6">Veuillez vous connecter pour accéder au scanner</p>
          <Button className="w-full" onClick={() => window.location.href = '/'}>
            Accueil
          </Button>
        </Card>
      </div>
    );
  }

  if (!selectedEvent) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-bold text-gray-900">QR Scanner - Sélection d'événement</h1>
            <Button variant="outline" size="sm" onClick={logout}>
              <LogOut className="w-4 h-4 mr-2" />
              Déconnexion
            </Button>
          </div>

          {eventsList.isLoading ? (
            <Card className="p-8 text-center">
              <p className="text-gray-600">Chargement des événements...</p>
            </Card>
          ) : eventsList.data && eventsList.data.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {eventsList.data.map(event => (
                <Card
                  key={event.id}
                  className="p-6 cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => setSelectedEvent({
                    id: event.id,
                    title: event.title,
                    location: event.location || undefined,
                    startTime: new Date(event.startTime),
                  })}
                >
                  <h3 className="text-lg font-semibold mb-2">{event.title}</h3>
                  <p className="text-sm text-gray-600 mb-2">{event.description}</p>
                  <p className="text-sm text-gray-500 mb-1">📍 {event.location}</p>
                  <p className="text-sm text-gray-500 mb-4">
                    {event.scannedTickets} / {event.totalTickets} billets scannés
                  </p>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-green-500 h-2 rounded-full transition-all"
                      style={{
                        width: `${event.totalTickets > 0 ? (event.scannedTickets / event.totalTickets) * 100 : 0}%`,
                      }}
                    />
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-8 text-center">
              <p className="text-gray-600">Aucun événement disponible</p>
            </Card>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{selectedEvent.title}</h1>
                  {selectedEvent.location && <p className="text-gray-600 mt-1">📍 {selectedEvent.location}</p>}
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownloadTickets}
              disabled={!eventWithTickets.data}
            >
              <Download className="w-4 h-4 mr-2" />
              Télécharger billets
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSelectedEvent(null)}
            >
              Changer d'événement
            </Button>
            <Button variant="outline" size="sm" onClick={logout}>
              <LogOut className="w-4 h-4 mr-2" />
              Déconnexion
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Scanner */}
          <div className="lg:col-span-2">
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4">Scanner QR</h2>
              <QRScanner
                onScan={handleScan}
                eventId={selectedEvent.id}
                isOffline={!isOnline}
              />
            </Card>
          </div>

          {/* Stats Sidebar */}
          <div className="space-y-4">
            <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-green-200">
              <h3 className="font-semibold text-lg mb-4">Statistiques</h3>
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-gray-600">Billets scannés</p>
                  <p className="text-3xl font-bold text-green-600">{eventStats.scannedTickets}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Total billets</p>
                  <p className="text-2xl font-bold text-gray-900">{eventStats.totalTickets}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-2">Progression</p>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div
                      className="bg-green-500 h-3 rounded-full transition-all"
                      style={{ width: `${eventStats.scanPercentage}%` }}
                    />
                  </div>
                  <p className="text-sm font-semibold text-gray-900 mt-1">{eventStats.scanPercentage}%</p>
                </div>
              </div>
            </Card>

            {/* Sync Status */}
            <Card className={`p-4 border-2 ${
              isOnline ? 'bg-green-50 border-green-200' : 'bg-orange-50 border-orange-200'
            }`}>
              <p className={`text-sm font-medium ${
                isOnline ? 'text-green-600' : 'text-orange-600'
              }`}>
                {isOnline ? '✓ En ligne' : '⚠ Hors-ligne'}
              </p>
              {pendingScans > 0 && (
                <p className="text-xs text-orange-600 mt-2">{pendingScans} scans en attente</p>
              )}
              {isSyncing && (
                <p className="text-xs text-blue-600 mt-2">Synchronisation...</p>
              )}
              <Button
                size="sm"
                variant="outline"
                className="w-full mt-3"
                onClick={performSync}
                disabled={isSyncing || isOnline}
              >
                {isSyncing ? 'Synchronisation...' : 'Synchroniser'}
              </Button>
            </Card>
          </div>
        </div>

        {/* Dashboard */}
        <div className="mt-8">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Tableau de bord</h2>
            <ScanDashboard
              eventId={selectedEvent.id}
              isOnline={isOnline}
              pendingScans={pendingScans}
            />
          </Card>
        </div>
      </div>
    </div>
  );
}
